// Script Name:    img-reducer-lamda-script.js
// Author:         Ajnur Ademi | Aron Herbel | Nicolas Haas
// Description:    Function for lambda to reduce our image 
// Date:           26. March 2024
// Version:        1.3

'use strict';

const AWS = require('aws-sdk');
const sharp = require('sharp');

exports.handler = async (event, context) => {
    // Creating an instance of the AWS S3 service
    const s3 = new AWS.S3();

    // Extracting the name of the original bucket from the S3 event
    const bucket = event.Records[0].s3.bucket.name;

    // Extracting the filename/key of the object triggering the event
    const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));

    // percentage resize 
    let percentageResize = process.env.PERCENTAGE_RESIZE;

    try {
        // Retrieving the image data from the original bucket
        const data = await s3.getObject({ Bucket: bucket, Key: key }).promise();
        const image = sharp(data.Body);

        // Calculating the new size + metadata for image 
        const metadata = await image.metadata();
        let size = Math.round(metadata.width * percentageResize / 100);
        console.log(`Resizing ${key} to ${size}`);
        let resizedImage = await image.resize(size).toBuffer();

        // Uploading the resized image to the specified bucket
        await s3.putObject({
            Body: resizedImage,
            Bucket: s3.listObjects(process.env.BUCKET_NAME_COMPRESSED).params,
            Key: `resized-${key}`,
            ContentType: 'image/jpeg'
        }).promise();

        console.log(`Resized ${key} & uploaded to bucket`);

    } catch (err) {
        console.error(err);
    }
};
