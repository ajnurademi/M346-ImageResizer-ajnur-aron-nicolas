// Script Name:    img-reducer-lamda-script.js
// Description:    Function for lambda to reduce our image 
// Author:         Ajnur Ademi | Aron Herbel | Nicolas Haas
// Date:           26. March 2024
// Version:        1.3

'use strict';

const AWS = require('aws-sdk');
const sharp = require('sharp');

exports.handler = async (event, context) => {
    const s3 = new AWS.S3();
    
    const bucket = event.Records[0].s3.bucket.name;

    const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));

    let percentageResize = process.env.PERCENTAGE_RESIZE;

    try {
        const data = await s3.getObject({ Bucket: bucket, Key: key }).promise();
        const image = sharp(data.Body);

        const metadata = await image.metadata();
        let size = Math.round(metadata.width * percentageResize / 100);
        console.log(`Resizing ${key} to ${size}`);
        let resizedImage = await image.resize(size).toBuffer();

        await s3.putObject({
            Body: resizedImage,
            Bucket: s3.listObjects(process.env.BUCKET_NAME_COMPRESSED).params,
            Key: `resized-${key}`,
            ContentType: 'image/jpeg'
        }).promise();

        console.log(`Resized ${key} and uploaded to target bucket`);

    } catch (err) {
        console.error(err);
    }
};